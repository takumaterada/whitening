<?php 
/*
 * Template Name: サンプル固定ページ
 */
?>
<?php get_header(); ?>
  <main class="l-main">
  </main>
<?php get_footer(); ?>