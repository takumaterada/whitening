<?php get_header(); ?>
<main id="primary" class="l-main">
	<h1>404エラー</h1>
	<p>このページは存在しません。</p>
	<?php the_content();?>
</main>
<?php
get_footer();
