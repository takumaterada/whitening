<?php get_header(); ?>
<main id="primary" class="l-main">
	<?php the_content();?>
</main>
<?php
get_footer();
