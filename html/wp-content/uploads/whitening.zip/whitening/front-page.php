<?php
/*
 * Template Name: TOPページ
 */
?>
<?php get_header(); ?>

<main class="l-main">
  <div class="c-fv">
    <div class="c-fv__content">
      <h1 class="c-fv__title">銀座で<br>月１万円で通い放題な<br>歯のホワイトニング個室サロン</h1>
    </div>
  </div>
  <div class="c-home">
    <p class="c-home__title--english">Home</p>
    <p class="c-home__title">当店について</p>
    <div class="c-home__container">
      <div class="c-home__img-group">
        <div class="c-home__wrapper"><img src="<?php bloginfo('template_url'); ?>/images/chemicals@2x.jpg" alt="器具" class="c-home__img"></div>
        <div class="c-home__wrapper --right"><img src="<?php bloginfo('template_url'); ?>/images/instrument@2x.jpg" alt="薬品" class="c-home__img"></div>
      </div>
      <div class="c-home__text-area">
        <p class="c-home__bg-text">白さ<br>眩しく<br>透き通る</p>
        <p class="c-home__catch"><span class="c-home__catch --accent">空いた時間</span>を上手に使って、<br>歯を<span class="c-home__catch --accent">ホワイトニング</span>しませんか</p>
        <p class="c-home__description">東銀座、銀座、銀座一丁目の各駅から徒歩数分。<br>瀟洒なマンションの一室、完全個室タイプのお部屋で、<br>1回約45分、月1万円で何度でもご利用可能。</p>
        <p class="c-home__text">高品質なオリジナルジェル、高出力の最新マシン、<br>経験豊富なスタッフによるサポートが、<br>あなたの歯をあなたらしく輝かせます。</p>
        <div class="c-home__price">
          <div class="c-home__circle"></div>
          <a href="#" class="c-home__link">料金システムへ</a>
        </div>
      </div>
    </div>
  </div>
  <div class="c-img-section">
    <div class="c-img-section__content">
      <div class="c-img-section__text-area">
        <p class="c-img-section__title">銀座 de ホワイトニング</p>
        <p class="c-img-section__text">月1万円で通い放題の<br>歯のホワイトニング個室サロン<br><br>1回45分、セルフ型、当日予約OK</p>
        <p class="c-img-section__title --bottom">男性の方も多くご利用されています</p>
      </div>
    </div>
  </div>
  <div class="c-reason">
    <p class="c-reason__title--english">Reason</p>
    <p class="c-reason__title">選ばれる理由</p>
    <p class="c-reason__text">歯を本来の明るさに戻していく<span class="c-reason__text --accent">セルフホワイトニング</span><br>オリジナルジェルと最新マシンで、当店ならではの<span class="c-reason__text --accent">効果を実現</span></p>
    <div class="c-reason__wrapper">
      <img src="<?php bloginfo('template_url'); ?>/images/feature@2x.png" alt="特徴" class="c-home__img">
    </div>
    <p class="c-reason__description">当店のホワイトニングは、歯を本来の明るさに戻していく、全く新しいホワイトニングです。<br>お客様ご自身で行っていただきますが、スタッフがマンツーマンでサポート致しますので<br>安心してご利用いただけます。完全プライベート空間なので、他のお客様の目を気にせず、<br>リラックスして行えるのも特徴です。</p>
  </div>
  <div class="c-media">
    <div class="c-media__text-area">
      <p class="c-media__title">2つの<span class="c-media__title --accent">光触媒</span>を配合したジェル、<br><span class="c-media__title --accent">3種類</span>の<span class="c-media__title --accent">照射光</span>が実現する<br>ハイクオリティ</p>
      <p class="c-media__text">研究開発を重ねた当店オリジナルジェル「プラチナムGE」には、酸化チタン、酸化タングステンを配合。<br>ジェルを塗った歯に、高出力65Wの最新マシンから2種類(青、赤、黄)のLED光を照射することで、2つの光触媒が高い相乗効果を生み出します。</p>
    </div>
    <div class="c-media__img-group">
      <div class="c-media__wrapper"><img src="<?php bloginfo('template_url'); ?>/images/light@2x.jpg" alt="光器具" class="c-media__img"></div>
      <div class="c-media__wrapper --right"><img src="<?php bloginfo('template_url'); ?>/images/chemicals@2x.jpg" alt="薬品" class="c-media__img"></div>
    </div>
  </div>
  <div class="c-change">
    <div class="c-change__content">
      <div class="c-change__wrapper">
        <img src="<?php bloginfo('template_url'); ?>/images/before@2x.png" alt="治療前" class="c-change__img">
      </div>
      <p class="c-change__caption --before">Before</p>
    </div>
    <div class="c-change__triangle"></div>
    <div class="c-change__content">
      <div class="c-change__wrapper">
        <img src="<?php bloginfo('template_url'); ?>/images/after@2x.png" alt="治療後" class="c-change__img">
      </div>
      <p class="c-change__caption --after">After</p>
    </div>
  </div>
  <div class="c-feature">
    <p class="c-feature__title">当店の特徴</p>
    <div class="c-feature__card">
      <div class="c-feature__card-circle"></div>
    </div>
  </div>

</main>

<?php get_footer(); ?>
