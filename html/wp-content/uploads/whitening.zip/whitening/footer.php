<?php wp_footer(); ?>
	<body>
		<div class="c-footer">
			<div class="c-footer__content">
				<p class="c-footer__text">© Copyright 2022 銀座でホワイトニングするなら『銀座deホワイトニング』／完全個室セルフホワイトニングサロン. All rights reserved.</p>
			</div>
		</div>
	</body>
</html>
